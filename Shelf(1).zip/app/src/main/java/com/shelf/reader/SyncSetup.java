package com.shelf.reader;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** The ↻ screen: connect this device to the GitHub sync file, sync now, or disconnect. */
final class SyncSetup {
    private static final String NEW_KEY =
            "https://github.com/settings/tokens/new?scopes=gist&description=Shelf%20sync";

    private SyncSetup() {}

    static void show(final Activity a, final Runnable changed) {
        if (Sync.connected(a)) showConnected(a, changed);
        else showConnect(a, changed);
    }

    private static TextView text(Activity a, String s) {
        TextView t = new TextView(a);
        t.setText(s);
        t.setTextSize(14);
        t.setTextColor(Ui.INK);
        t.setLineSpacing(Ui.dp(a, 3), 1f);
        return t;
    }

    private static void showConnect(final Activity a, final Runnable changed) {
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(a, 22), Ui.dp(a, 12), Ui.dp(a, 22), 0);
        box.addView(text(a, "Keeps your reading position, Currently Reading shelf, bookmarks, quotes and words "
                + "the same on all your devices, through a private file on your GitHub account.\n\n"
                + "1.  Tap “Create key” and sign in to GitHub.\n"
                + "2.  Set Expiration to “No expiration”, scroll down and tap “Generate token”.\n"
                + "3.  Copy the key (it starts with ghp_) and paste it here.\n\n"
                + "Use the same key on your other device. The key can only read and write your gists, "
                + "nothing else on your account."));
        final EditText key = new EditText(a);
        key.setHint("ghp_…");
        key.setSingleLine(true);
        key.setTypeface(Typeface.MONOSPACE);
        key.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(a, 12);
        box.addView(key, lp);

        final AlertDialog dialog = new AlertDialog.Builder(a)
                .setTitle("Sync across your devices")
                .setView(box)
                .setPositiveButton("Connect", null)
                .setNeutralButton("Create key", null)
                .setNegativeButton("Cancel", null)
                .create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                try {
                    a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(NEW_KEY)));
                } catch (Exception e) {
                    Ui.toast(a, "No browser found. Open github.com → Settings → Developer settings → Tokens");
                }
            }
        });
        final View connect = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
        connect.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                final String token = key.getText().toString().trim();
                if (token.length() < 20) {
                    Ui.toast(a, "Paste the key from GitHub first");
                    return;
                }
                connect.setEnabled(false);
                Ui.toast(a, "Connecting…");
                new Thread(new Runnable() {
                    @Override public void run() {
                        String error = null;
                        try {
                            Sync.connect(a, token);
                        } catch (Exception e) {
                            error = e.getMessage() == null ? "Couldn't connect" : e.getMessage();
                            if (e instanceof java.net.UnknownHostException) error = "No internet";
                        }
                        final String why = error;
                        a.runOnUiThread(new Runnable() {
                            @Override public void run() {
                                if (a.isDestroyed()) return;
                                connect.setEnabled(true);
                                if (why != null) {
                                    Ui.toast(a, "Couldn't connect: " + why);
                                    return;
                                }
                                dialog.dismiss();
                                Ui.toast(a, "Connected as " + Sync.account(a) + ". Syncing…");
                                Sync.request(a);
                                changed.run();
                            }
                        });
                    }
                }).start();
            }
        });
    }

    private static void showConnected(final Activity a, final Runnable changed) {
        long last = Sync.lastSync(a);
        String when = last == 0 ? "not yet"
                : android.text.format.DateUtils.getRelativeTimeSpanString(last).toString();
        String error = Sync.lastError(a);
        String msg = "Connected to GitHub as " + Sync.account(a) + ".\n\nLast sync: " + when
                + (error.isEmpty() ? "" : "\nLast attempt: " + error)
                + "\n\nShelf syncs by itself when you open the app and when you close a book.";
        new AlertDialog.Builder(a)
                .setTitle("Sync")
                .setMessage(msg)
                .setPositiveButton("Sync now", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) {
                        Sync.request(a);
                        Ui.toast(a, "Syncing…");
                    }
                })
                .setNeutralButton("Disconnect", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) {
                        Sync.disconnect(a);
                        Ui.toast(a, "Disconnected. Your books and quotes stay on this device.");
                        changed.run();
                    }
                })
                .setNegativeButton("Close", null)
                .show();
    }
}

package com.shelf.reader;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/**
 * A round drawing-tool button with a drawn icon: pen, highlighter or eraser.
 * The big one is red and shows the tool in use; the small ones are dark and show the others.
 */
final class ToolButton extends View {
    final boolean big;
    int tool = PdfPageView.PEN;
    /** Colour of the pen or highlighter, shown as a small dot. */
    int color = 0xFFE53935;
    /** Drawing is on: the big circle gets a bright ring. */
    boolean active;
    /** While the tools menu is open the big circle shows ✕ (tap to close), as before. */
    boolean close;

    private final float d;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final Path path = new Path();

    ToolButton(Context c, boolean big) {
        super(c);
        this.big = big;
        d = c.getResources().getDisplayMetrics().density;
    }

    void set(int tool, int color, boolean active) {
        this.tool = tool;
        this.color = color;
        this.active = active;
        setContentDescription(tool == PdfPageView.MARKER ? "Highlighter" : tool == PdfPageView.ERASER ? "Eraser" : "Pen");
        invalidate();
    }

    @Override protected void onDraw(Canvas canvas) {
        float w = getWidth(), h = getHeight(), cx = w / 2f, cy = h / 2f;
        float rad = Math.min(w, h) / 2f - (big ? 4 : 2) * d;
        if (rad <= 0) return;

        // The circle.
        paint.setStyle(Paint.Style.FILL);
        if (big && active) {
            paint.setColor(0x55FFFFFF);
            canvas.drawCircle(cx, cy, rad + 3.5f * d, paint);
        }
        paint.setColor(big ? 0xFFE53935 : 0xF2141418);
        canvas.drawCircle(cx, cy, rad, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth((big ? (active ? 3f : 2f) : 1.5f) * d);
        paint.setColor(big ? (active ? 0xFFFFFFFF : 0x66FFFFFF) : 0xCCE53935);
        canvas.drawCircle(cx, cy, rad, paint);

        int ink = big ? 0xFFFFFFFF : 0xFFE8E2D4;
        if (big && close) {
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setStrokeWidth(3.2f * d);
            paint.setColor(ink);
            float k = rad * 0.38f;
            canvas.drawLine(cx - k, cy - k, cx + k, cy + k, paint);
            canvas.drawLine(cx - k, cy + k, cx + k, cy - k, paint);
            return;
        }

        // The icon, drawn on a slant like a tool held in the hand.
        float s = rad * 1.25f;
        canvas.save();
        canvas.translate(cx, cy - (tool == PdfPageView.ERASER ? 0 : 0.06f * s));
        canvas.rotate(-45);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(ink);
        if (tool == PdfPageView.PEN) {
            r.set(-0.42f * s, -0.09f * s, 0.20f * s, 0.09f * s);
            canvas.drawRoundRect(r, 0.03f * s, 0.03f * s, paint);
            path.reset();
            path.moveTo(0.24f * s, -0.09f * s);
            path.lineTo(0.42f * s, 0);
            path.lineTo(0.24f * s, 0.09f * s);
            path.close();
            canvas.drawPath(path, paint);
        } else if (tool == PdfPageView.MARKER) {
            r.set(-0.40f * s, -0.13f * s, 0.12f * s, 0.13f * s);
            canvas.drawRoundRect(r, 0.04f * s, 0.04f * s, paint);
            path.reset();
            path.moveTo(0.15f * s, -0.13f * s);
            path.lineTo(0.38f * s, -0.07f * s);
            path.lineTo(0.38f * s, 0.05f * s);
            path.lineTo(0.15f * s, 0.13f * s);
            path.close();
            canvas.drawPath(path, paint);
        } else {
            r.set(-0.36f * s, -0.15f * s, 0.36f * s, 0.15f * s);
            canvas.drawRoundRect(r, 0.06f * s, 0.06f * s, paint);
            paint.setColor(big ? 0xFFE53935 : 0xF2141418);
            canvas.drawRect(-0.06f * s, -0.15f * s, -0.02f * s, 0.15f * s, paint);
        }
        canvas.restore();

        // A dot in the pen's or highlighter's colour.
        if (tool != PdfPageView.ERASER) {
            float dot = (big ? 4.5f : 3.5f) * d, y = cy + rad * 0.55f;
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(0xFFFFFFFF);
            canvas.drawCircle(cx, y, dot + 1.2f * d, paint);
            paint.setColor(color);
            canvas.drawCircle(cx, y, dot, paint);
        }
    }
}

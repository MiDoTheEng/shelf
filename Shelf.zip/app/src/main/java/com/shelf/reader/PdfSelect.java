package com.shelf.reader;

import android.graphics.Point;
import android.graphics.RectF;
import android.graphics.pdf.PdfRenderer;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * Selecting text on a PDF page. Android only offers this from version 15 on, so the
 * system calls are looked up by name at run time and older phones report "unsupported".
 */
final class PdfSelect {
    /** One end of a selection: a character index, or a spot on the page (0..1 across and down). */
    static final class Bound {
        final int index;
        final float u, v;

        private Bound(int index, float u, float v) {
            this.index = index;
            this.u = u;
            this.v = v;
        }

        static Bound at(float u, float v) {
            return new Bound(-1, u, v);
        }

        static Bound index(int i) {
            return new Bound(i, 0, 0);
        }
    }

    static final class Result {
        String text = "";
        /** One rectangle per selected line, as fractions of the page width and height. */
        final ArrayList<RectF> rects = new ArrayList<>();
        int startIndex = -1, stopIndex = -1;
        boolean rtl;
        boolean unsupported;
    }

    private PdfSelect() {}

    private static Object boundary(Class<?> type, Bound b, float pw, float ph) throws Exception {
        if (b.index >= 0) return type.getConstructor(int.class).newInstance(b.index);
        return type.getConstructor(Point.class).newInstance(new Point(Math.round(b.u * pw), Math.round(b.v * ph)));
    }

    private static Object invoke(Method select, Object page, Object start, Object stop) throws IllegalAccessException {
        try {
            return select.invoke(page, start, stop);
        } catch (InvocationTargetException e) {
            return null;
        }
    }

    /** Selects from a to b; when both are the same spot, the word there. Must run off the main thread. */
    static Result select(PdfRenderer.Page page, Bound a, Bound b) {
        Result r = new Result();
        try {
            Class<?> type = Class.forName("android.graphics.pdf.models.selection.SelectionBoundary");
            Method select = page.getClass().getMethod("selectContent", type, type);
            float pw = Math.max(1, page.getWidth()), ph = Math.max(1, page.getHeight());
            Object sel = invoke(select, page, boundary(type, a, pw, ph), boundary(type, b, pw, ph));
            boolean same = a.index == b.index && a.u == b.u && a.v == b.v;
            if (sel == null && !same) {
                // Dragged back past the starting point: ask again the other way round.
                sel = invoke(select, page, boundary(type, b, pw, ph), boundary(type, a, pw, ph));
            }
            if (sel == null) return r;

            StringBuilder text = new StringBuilder();
            Object contents = sel.getClass().getMethod("getSelectedTextContents").invoke(sel);
            if (contents instanceof List) {
                for (Object c : (List<?>) contents) {
                    Object t = c.getClass().getMethod("getText").invoke(c);
                    if (t != null) text.append(t).append(' ');
                    Object bounds = c.getClass().getMethod("getBounds").invoke(c);
                    if (!(bounds instanceof List)) continue;
                    for (Object o : (List<?>) bounds) {
                        if (!(o instanceof RectF)) continue;
                        RectF q = (RectF) o;
                        r.rects.add(new RectF(Math.min(q.left, q.right) / pw, Math.min(q.top, q.bottom) / ph,
                                Math.max(q.left, q.right) / pw, Math.max(q.top, q.bottom) / ph));
                    }
                }
            }
            r.text = text.toString().trim();
            Object start = sel.getClass().getMethod("getStart").invoke(sel);
            Object stop = sel.getClass().getMethod("getStop").invoke(sel);
            r.startIndex = (Integer) start.getClass().getMethod("getIndex").invoke(start);
            r.stopIndex = (Integer) stop.getClass().getMethod("getIndex").invoke(stop);
            r.rtl = (Boolean) start.getClass().getMethod("getIsRtl").invoke(start);
        } catch (ClassNotFoundException | NoSuchMethodException e) {
            r.unsupported = true;
        } catch (Throwable ignored) {
        }
        return r;
    }
}

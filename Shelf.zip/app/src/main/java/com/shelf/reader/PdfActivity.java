package com.shelf.reader;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfRenderer;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.os.SystemClock;
import android.text.InputType;
import android.util.LruCache;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.io.File;
import java.util.Arrays;
import java.util.HashSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Continuous-scroll PDF reader with pinch zoom and a night mode. */
public class PdfActivity extends Activity {
    private static final ColorMatrixColorFilter INVERT = new ColorMatrixColorFilter(new ColorMatrix(new float[]{
            -1, 0, 0, 0, 255,
            0, -1, 0, 0, 255,
            0, 0, -1, 0, 255,
            0, 0, 0, 1, 0}));

    /** A frame whose width is dictated by the zoom level so it can scroll sideways. */
    private static final class FixedWidthFrame extends FrameLayout {
        int fixedWidth = 1;

        FixedWidthFrame(Context c) {
            super(c);
        }

        @Override protected void onMeasure(int widthSpec, int heightSpec) {
            super.onMeasure(MeasureSpec.makeMeasureSpec(fixedWidth, MeasureSpec.EXACTLY), heightSpec);
        }
    }

    private Library lib;
    private Book book;
    private SharedPreferences prefs;
    private PdfRenderer renderer;
    private final ExecutorService exec = Executors.newSingleThreadExecutor();
    private LruCache<Integer, Bitmap> cache;
    private final HashSet<Integer> pending = new HashSet<>();
    private float[] aspect = new float[0];
    private int pageCount;
    private int baseWidth;
    private int maxRenderWidth;
    private float zoom = 1f;
    private volatile int generation;
    private volatile int firstVisible;
    private volatile int lastVisible;
    private volatile boolean closed;
    private boolean night;

    private ListView list;
    private FixedWidthFrame frame;
    private HorizontalScrollView sideways;
    private PageAdapter adapter;
    private View topBar;
    private TextView pill;
    private TextView nightButton;
    private ScaleGestureDetector scaler;
    private boolean pinching;
    private float pinch = 1f;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        lib = Library.get(this);
        prefs = getSharedPreferences("shelf", MODE_PRIVATE);
        night = prefs.getBoolean("pdfNight", false);
        String id = getIntent().getStringExtra("id");
        book = id == null ? null : lib.find(id);
        if (book == null) {
            finish();
            return;
        }

        ParcelFileDescriptor pfd = null;
        try {
            pfd = ParcelFileDescriptor.open(new File(book.file), ParcelFileDescriptor.MODE_READ_ONLY);
            renderer = new PdfRenderer(pfd);
            pageCount = renderer.getPageCount();
            if (pageCount <= 0) throw new IllegalStateException("empty");
            PdfRenderer.Page first = renderer.openPage(0);
            float a = first.getHeight() / (float) Math.max(1, first.getWidth());
            first.close();
            aspect = new float[pageCount];
            Arrays.fill(aspect, a);
        } catch (Exception e) {
            try {
                if (renderer != null) renderer.close();
                else if (pfd != null) pfd.close();
            } catch (Exception ignored) {
            }
            renderer = null;
            Ui.toast(this, "This PDF can't be opened (it may be password-protected or damaged)");
            finish();
            return;
        }

        long maxKb = Runtime.getRuntime().maxMemory() / 1024;
        maxRenderWidth = maxKb < 200 * 1024 ? 1500 : 2200;
        cache = new LruCache<Integer, Bitmap>((int) Math.min(Integer.MAX_VALUE, maxKb / 4)) {
            @Override protected int sizeOf(Integer key, Bitmap value) {
                return Math.max(1, value.getByteCount() / 1024);
            }
        };
        baseWidth = getResources().getDisplayMetrics().widthPixels;

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF0A0A0D);

        list = new ListView(this);
        list.setDivider(new ColorDrawable(0xFF0A0A0D));
        list.setDividerHeight(Ui.dp(this, 6));
        list.setSelector(new ColorDrawable(0));
        list.setCacheColorHint(0);
        list.setOverScrollMode(View.OVER_SCROLL_NEVER);
        adapter = new PageAdapter();
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> parent, View view, int position, long rowId) {
                topBar.setVisibility(topBar.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
            }
        });
        list.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override public void onScrollStateChanged(AbsListView view, int scrollState) {
                if (scrollState != SCROLL_STATE_IDLE) return;
                for (int i = 0; i < view.getChildCount(); i++) {
                    View child = view.getChildAt(i);
                    if (child instanceof ImageView && ((ImageView) child).getDrawable() == null
                            && child.getTag() instanceof Integer) {
                        request((Integer) child.getTag());
                    }
                }
            }

            @Override public void onScroll(AbsListView view, int first, int visible, int total) {
                firstVisible = first;
                lastVisible = first + Math.max(1, visible) - 1;
                if (pill != null) pill.setText((first + 1) + " / " + pageCount);
            }
        });

        frame = new FixedWidthFrame(this);
        frame.fixedWidth = pageWidth();
        frame.addView(list, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        sideways = new HorizontalScrollView(this);
        sideways.setHorizontalScrollBarEnabled(false);
        sideways.setOverScrollMode(View.OVER_SCROLL_NEVER);
        sideways.addView(frame, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        root.addView(sideways, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout bar = Ui.bar(this);
        bar.addView(Ui.barButton(this, "‹", 26, new View.OnClickListener() {
            @Override public void onClick(View v) {
                finish();
            }
        }));
        bar.addView(Ui.barTitle(this, book.title), new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        nightButton = Ui.barButton(this, night ? "Day" : "Night", 14, new View.OnClickListener() {
            @Override public void onClick(View v) {
                night = !night;
                prefs.edit().putBoolean("pdfNight", night).apply();
                nightButton.setText(night ? "Day" : "Night");
                adapter.notifyDataSetChanged();
            }
        });
        bar.addView(nightButton);
        topBar = bar;
        root.addView(bar, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP));

        pill = new TextView(this);
        pill.setTextSize(12.5f);
        pill.setTextColor(Ui.INK);
        pill.setPadding(Ui.dp(this, 14), Ui.dp(this, 7), Ui.dp(this, 14), Ui.dp(this, 7));
        GradientDrawable pillBg = new GradientDrawable();
        pillBg.setColor(0xD9101014);
        pillBg.setCornerRadius(Ui.dp(this, 18));
        pillBg.setStroke(Ui.dp(this, 1), 0x55D4AF6A);
        pill.setBackground(pillBg);
        pill.setText("1 / " + pageCount);
        pill.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                askPage();
            }
        });
        FrameLayout.LayoutParams plp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        plp.bottomMargin = Ui.dp(this, 18);
        root.addView(pill, plp);

        scaler = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScaleBegin(ScaleGestureDetector detector) {
                pinching = true;
                pinch = 1f;
                long now = SystemClock.uptimeMillis();
                MotionEvent cancel = MotionEvent.obtain(now, now, MotionEvent.ACTION_CANCEL, 0, 0, 0);
                PdfActivity.super.dispatchTouchEvent(cancel);
                cancel.recycle();
                frame.setPivotX(detector.getFocusX() + sideways.getScrollX());
                frame.setPivotY(detector.getFocusY());
                return true;
            }

            @Override public boolean onScale(ScaleGestureDetector detector) {
                pinch *= detector.getScaleFactor();
                float target = Math.max(1f, Math.min(4f, zoom * pinch));
                frame.setScaleX(target / zoom);
                frame.setScaleY(target / zoom);
                return true;
            }
        });

        setContentView(root);
        int start = Math.max(0, Math.min(pageCount - 1, book.chapter));
        firstVisible = start;
        lastVisible = start;
        list.setSelection(start);
        ReaderActivity.autoHide(root, topBar);
    }

    @Override public boolean dispatchTouchEvent(MotionEvent ev) {
        if (scaler != null) {
            scaler.onTouchEvent(ev);
            if (pinching) {
                int action = ev.getActionMasked();
                if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                    pinching = false;
                    frame.setScaleX(1f);
                    frame.setScaleY(1f);
                    setZoom(zoom * pinch);
                }
                return true;
            }
        }
        return super.dispatchTouchEvent(ev);
    }

    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (renderer == null) return;
        baseWidth = getResources().getDisplayMetrics().widthPixels;
        relayoutPages(1f);
    }

    private int pageWidth() {
        return Math.max(1, Math.round(baseWidth * zoom));
    }

    private void setZoom(float z) {
        z = Math.max(1f, Math.min(4f, z));
        if (Math.abs(z - zoom) < 0.02f) return;
        float ratio = z / zoom;
        zoom = z;
        relayoutPages(ratio);
    }

    private void relayoutPages(float ratio) {
        int pos = list.getFirstVisiblePosition();
        View top = list.getChildAt(0);
        int offset = top == null ? 0 : Math.round(top.getTop() * ratio);
        generation++;
        cache.evictAll();
        pending.clear();
        frame.fixedWidth = pageWidth();
        frame.requestLayout();
        adapter.notifyDataSetChanged();
        list.setSelectionFromTop(pos, offset);
    }

    private void askPage() {
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setHint("1 – " + pageCount);
        FrameLayout wrap = new FrameLayout(this);
        wrap.setPadding(Ui.dp(this, 22), Ui.dp(this, 8), Ui.dp(this, 22), 0);
        wrap.addView(input);
        new AlertDialog.Builder(this)
                .setTitle("Go to page")
                .setView(wrap)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Go", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        try {
                            int page = Integer.parseInt(input.getText().toString().trim());
                            list.setSelection(Math.max(1, Math.min(pageCount, page)) - 1);
                        } catch (NumberFormatException ignored) {
                        }
                    }
                })
                .show();
    }

    private final class PageAdapter extends BaseAdapter {
        @Override public int getCount() { return pageCount; }
        @Override public Object getItem(int position) { return position; }
        @Override public long getItemId(int position) { return position; }

        @Override public View getView(int position, View convertView, ViewGroup parent) {
            ImageView iv = convertView instanceof ImageView ? (ImageView) convertView : new ImageView(PdfActivity.this);
            int w = pageWidth();
            int h = Math.max(1, Math.round(w * aspect[position]));
            ViewGroup.LayoutParams lp = iv.getLayoutParams();
            if (lp == null) {
                lp = new AbsListView.LayoutParams(w, h);
            } else {
                lp.width = w;
                lp.height = h;
            }
            iv.setLayoutParams(lp);
            iv.setScaleType(ImageView.ScaleType.FIT_XY);
            iv.setBackgroundColor(night ? 0xFF16161A : 0xFFF4F4F4);
            iv.setColorFilter(night ? INVERT : null);
            iv.setTag(position);
            Bitmap bmp = cache.get(position);
            iv.setImageBitmap(bmp);
            if (bmp == null) request(position);
            return iv;
        }
    }

    private void request(final int pos) {
        if (pos < firstVisible) firstVisible = pos;
        if (pos > lastVisible) lastVisible = pos;
        if (!pending.add(pos)) return;
        final int gen = generation;
        final int w = Math.min(pageWidth(), maxRenderWidth);
        exec.execute(new Runnable() {
            @Override public void run() {
                Bitmap bmp = null;
                float a = 0f;
                try {
                    if (!closed && gen == generation && pos >= firstVisible - 2 && pos <= lastVisible + 2) {
                        PdfRenderer.Page page = renderer.openPage(pos);
                        try {
                            a = page.getHeight() / (float) Math.max(1, page.getWidth());
                            int h = Math.max(1, Math.round(w * a));
                            bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                            bmp.eraseColor(Color.WHITE);
                            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                        } finally {
                            page.close();
                        }
                    }
                } catch (Throwable t) {
                    bmp = null;
                }
                final Bitmap result = bmp;
                final float pageAspect = a;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (gen == generation) pending.remove(pos);
                        if (closed || gen != generation || result == null) return;
                        cache.put(pos, result);
                        if (Math.abs(aspect[pos] - pageAspect) > 0.01f) {
                            aspect[pos] = pageAspect;
                            adapter.notifyDataSetChanged();
                            return;
                        }
                        for (int i = 0; i < list.getChildCount(); i++) {
                            View child = list.getChildAt(i);
                            if (child instanceof ImageView && Integer.valueOf(pos).equals(child.getTag())) {
                                ((ImageView) child).setImageBitmap(result);
                            }
                        }
                    }
                });
            }
        });
    }

    @Override protected void onPause() {
        super.onPause();
        if (book != null && renderer != null && list != null) {
            int first = Math.max(0, list.getFirstVisiblePosition());
            book.chapter = first;
            book.progress = pageCount <= 1 ? 1f : Math.min(1f, (first + 1) / (float) pageCount);
            if (list.getLastVisiblePosition() >= pageCount - 1) book.progress = 1f;
            lib.save();
        }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        closed = true;
        final PdfRenderer r = renderer;
        if (r != null) {
            exec.execute(new Runnable() {
                @Override public void run() {
                    try {
                        r.close();
                    } catch (Exception ignored) {
                    }
                }
            });
        }
        exec.shutdown();
    }
}

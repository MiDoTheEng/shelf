package com.shelf.reader;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

/**
 * English to Arabic translation on the phone itself (Google ML Kit). The dictionary is
 * downloaded once, about 30 MB; after that it works without internet.
 */
final class Translate {
    private static Translator client;

    private Translate() {}

    private static Translator client() {
        if (client == null) {
            client = Translation.getClient(new TranslatorOptions.Builder()
                    .setSourceLanguage(TranslateLanguage.ENGLISH)
                    .setTargetLanguage(TranslateLanguage.ARABIC)
                    .build());
        }
        return client;
    }

    /** Translates the text, shows the Arabic in a small box and saves it to the Words tab. */
    static void show(final Activity a, final String text, final String bookTitle) {
        if (text == null || text.trim().isEmpty()) {
            Ui.toast(a, "Select a word or sentence first");
            return;
        }
        final String source = text.trim();
        final TextView arabic = new TextView(a);
        arabic.setTextSize(21);
        arabic.setTextColor(Ui.INK);
        arabic.setGravity(Gravity.END);
        arabic.setTextDirection(View.TEXT_DIRECTION_RTL);
        arabic.setLineSpacing(Ui.dp(a, 4), 1f);
        arabic.setTextIsSelectable(true);
        arabic.setText("…");

        final TextView status = new TextView(a);
        status.setTextSize(12.5f);
        status.setTextColor(0x99B8B2A6);
        status.setPadding(0, Ui.dp(a, 10), 0, 0);
        status.setText("Translating…  The first time, the English–Arabic dictionary downloads once "
                + "(about 30 MB), so this needs internet and can take a minute.");

        TextView original = new TextView(a);
        original.setTextSize(14);
        original.setTextColor(0xCCD4AF6A);
        original.setTypeface(Typeface.create(Typeface.SERIF, Typeface.ITALIC));
        original.setText(source);
        original.setPadding(0, 0, 0, Ui.dp(a, 12));

        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(a, 22), Ui.dp(a, 18), Ui.dp(a, 22), Ui.dp(a, 6));
        box.addView(original);
        box.addView(arabic);
        box.addView(status);
        ScrollView scroll = new ScrollView(a);
        scroll.addView(box);

        final AlertDialog dialog = new AlertDialog.Builder(a)
                .setView(scroll)
                .setPositiveButton("OK", null)
                .setNeutralButton("Copy", null)
                .create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                ClipboardManager cm = (ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("Translation", arabic.getText()));
                Ui.toast(a, "Copied");
            }
        });

        final Translator t = client();
        final OnFailureListener failed = new OnFailureListener() {
            @Override public void onFailure(Exception e) {
                if (a.isDestroyed()) return;
                arabic.setText("");
                status.setText("Couldn't translate. The first time needs an internet connection "
                        + "to download the dictionary — connect and try again.");
            }
        };
        t.downloadModelIfNeeded().addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override public void onSuccess(Void v) {
                t.translate(source).addOnSuccessListener(new OnSuccessListener<String>() {
                    @Override public void onSuccess(String result) {
                        String ar = result == null ? "" : result.trim();
                        if (ar.isEmpty()) {
                            failed.onFailure(new Exception("empty"));
                            return;
                        }
                        Words.add(a.getApplicationContext(), source, ar, bookTitle);
                        if (a.isDestroyed()) return;
                        arabic.setText(ar);
                        status.setText("Saved to Words");
                    }
                }).addOnFailureListener(failed);
            }
        }).addOnFailureListener(failed);
    }
}

package com.shelf.reader;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.shelf.reader.core.BookContent;
import com.shelf.reader.core.EpubBook;
import com.shelf.reader.core.MobiBook;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.util.ArrayList;

/** Reader for EPUB and Kindle (MOBI/AZW3) books: one chapter at a time in a WebView. */
public class ReaderActivity extends Activity {
    private static final String HOST = "shelf.book";
    private static final String[] THEMES = {"dark", "sepia", "light"};

    private Library lib;
    private Book book;
    private SharedPreferences prefs;
    private BookContent content;
    private long[] weights = new long[0];
    private long totalWeight = 1;
    private int chapter;
    private float pendingOffset = -1f;
    private volatile float fraction;
    private boolean destroyed;

    private FrameLayout root;
    private WebView web;
    private View topBar;
    private View bottomBar;
    private TextView label;
    private TextView loading;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        lib = Library.get(this);
        prefs = getSharedPreferences("shelf", MODE_PRIVATE);
        String id = getIntent().getStringExtra("id");
        book = id == null ? null : lib.find(id);
        if (book == null) {
            finish();
            return;
        }

        root = new FrameLayout(this);
        root.setBackgroundColor(background());

        web = new WebView(this);
        web.setBackgroundColor(background());
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        loading = new TextView(this);
        loading.setText("Opening…");
        loading.setTextSize(15);
        loading.setTextColor(0xFF8C8778);
        root.addView(loading, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));

        LinearLayout top = Ui.bar(this);
        top.addView(Ui.barButton(this, "‹", 26, new View.OnClickListener() {
            @Override public void onClick(View v) {
                finish();
            }
        }));
        top.addView(Ui.barTitle(this, book.title), new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        top.addView(Ui.barButton(this, "Aa", 16, new View.OnClickListener() {
            @Override public void onClick(View v) {
                showTextSettings();
            }
        }));
        top.addView(Ui.barButton(this, "Contents", 13, new View.OnClickListener() {
            @Override public void onClick(View v) {
                showContents();
            }
        }));
        topBar = top;
        root.addView(top, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP));

        LinearLayout bottom = Ui.bar(this);
        bottom.addView(Ui.barButton(this, "‹", 26, new View.OnClickListener() {
            @Override public void onClick(View v) {
                go(chapter - 1, 0f);
            }
        }));
        label = new TextView(this);
        label.setTextSize(13);
        label.setTextColor(Ui.INK);
        label.setGravity(Gravity.CENTER);
        bottom.addView(label, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        bottom.addView(Ui.barButton(this, "›", 26, new View.OnClickListener() {
            @Override public void onClick(View v) {
                go(chapter + 1, 0f);
            }
        }));
        bottomBar = bottom;
        root.addView(bottom, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM));

        setContentView(root);

        final File file = new File(book.file);
        final boolean epub = book.format.equals("epub");
        new Thread(new Runnable() {
            @Override public void run() {
                BookContent opened = null;
                String error = null;
                try {
                    opened = epub ? new EpubBook(file) : new MobiBook(file);
                } catch (Exception | OutOfMemoryError e) {
                    error = e.getMessage() == null ? "This book could not be opened" : e.getMessage();
                }
                final BookContent result = opened;
                final String message = error;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (destroyed) {
                            closeQuietly(result);
                        } else if (result == null) {
                            Ui.toast(ReaderActivity.this, message);
                            finish();
                        } else {
                            start(result);
                        }
                    }
                });
            }
        }).start();
    }

    private static void closeQuietly(BookContent c) {
        try {
            if (c != null) c.close();
        } catch (Exception ignored) {
        }
    }

    private void start(BookContent opened) {
        content = opened;
        int n = content.chapterCount();
        weights = new long[n];
        totalWeight = 0;
        for (int i = 0; i < n; i++) {
            weights[i] = Math.max(1, content.chapterWeight(i));
            totalWeight += weights[i];
        }
        chapter = Math.max(0, Math.min(n - 1, book.chapter));
        fraction = Math.max(0f, Math.min(1f, book.offset));
        pendingOffset = fraction;
        loading.setVisibility(View.GONE);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setBuiltInZoomControls(false);
        s.setSupportZoom(false);
        s.setTextZoom(prefs.getInt("textZoom", 110));
        web.addJavascriptInterface(new Bridge(), "Shelf");
        web.setWebViewClient(new Client());

        final GestureDetector swipes = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                if (e1 == null || e2 == null) return false;
                float dx = e2.getX() - e1.getX(), dy = e2.getY() - e1.getY();
                if (Math.abs(dx) > Ui.dp(ReaderActivity.this, 110) && Math.abs(dx) > 2.5f * Math.abs(dy)
                        && Math.abs(vx) > 700) {
                    go(dx < 0 ? chapter + 1 : chapter - 1, 0f);
                    return true;
                }
                return false;
            }
        });
        web.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent event) {
                swipes.onTouchEvent(event);
                return false;
            }
        });
        loadChapter();
        autoHide(web, topBar, bottomBar);
    }

    /** Leaves the bars up for a moment so they are discoverable, then gets out of the way. */
    static void autoHide(View host, final View... bars) {
        host.postDelayed(new Runnable() {
            @Override public void run() {
                for (View b : bars) b.setVisibility(View.GONE);
            }
        }, 3200);
    }

    // --------------------------------------------------------------- navigation

    private void go(int target, float offset) {
        if (content == null) return;
        if (target < 0) {
            Ui.toast(this, "This is the beginning of the book");
            return;
        }
        if (target >= content.chapterCount()) {
            Ui.toast(this, "You've reached the end of the book");
            return;
        }
        chapter = target;
        fraction = offset;
        pendingOffset = offset;
        loadChapter();
    }

    private void loadChapter() {
        web.setAlpha(0f);
        web.loadUrl("https://" + HOST + "/" + content.chapterPath(chapter));
        updateLabel();
        web.postDelayed(new Runnable() {
            @Override public void run() {
                if (!destroyed) web.setAlpha(1f);
            }
        }, 1500);
    }

    private float progress() {
        if (content == null || weights.length == 0) return book.progress;
        long before = 0;
        for (int i = 0; i < chapter && i < weights.length; i++) before += weights[i];
        float p = (before + weights[chapter] * fraction) / (float) totalWeight;
        return Math.max(0f, Math.min(1f, p));
    }

    private void updateLabel() {
        if (content == null) return;
        label.setText((chapter + 1) + " / " + content.chapterCount() + "   ·   "
                + Math.round(progress() * 100) + "%");
    }

    private void toggleBars() {
        int v = topBar.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE;
        topBar.setVisibility(v);
        bottomBar.setVisibility(v);
    }

    private final class Bridge {
        @JavascriptInterface public void onScroll(double f) {
            fraction = (float) Math.max(0, Math.min(1, f));
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if (!destroyed) updateLabel();
                }
            });
        }

        @JavascriptInterface public void tap() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if (!destroyed) toggleBars();
                }
            });
        }

        @JavascriptInterface public void next() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    if (!destroyed) go(chapter + 1, 0f);
                }
            });
        }
    }

    private final class Client extends WebViewClient {
        private WebResourceResponse missing() {
            WebResourceResponse r = new WebResourceResponse("text/plain", "utf-8",
                    new ByteArrayInputStream(new byte[0]));
            r.setStatusCodeAndReasonPhrase(404, "Not Found");
            return r;
        }

        @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            try {
                Uri u = request.getUrl();
                BookContent c = content;
                if (c == null || u == null || !HOST.equals(u.getHost()) || u.getPath() == null) return missing();
                String path = u.getPath();
                if (path.startsWith("/")) path = path.substring(1);
                BookContent.Res res = c.open(path);
                if (res == null) return missing();
                return new WebResourceResponse(res.mime, res.charset, res.in);
            } catch (Throwable t) {
                return missing();
            }
        }

        @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            Uri u = request.getUrl();
            if (u == null) return true;
            if (HOST.equals(u.getHost())) {
                String path = u.getPath() == null ? "" : u.getPath();
                if (path.startsWith("/")) path = path.substring(1);
                int idx = content == null ? -1 : content.chapterForPath(path);
                if (idx < 0) return true;
                chapter = idx;
                fraction = 0f;
                pendingOffset = 0f;
                web.setAlpha(0f);
                updateLabel();
                return false;
            }
            String scheme = u.getScheme();
            if ("http".equals(scheme) || "https".equals(scheme) || "mailto".equals(scheme)) {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) {
                }
            }
            return true;
        }

        @Override public void onPageFinished(WebView view, String url) {
            float offset = pendingOffset;
            pendingOffset = -1f;
            inject(offset);
            view.animate().alpha(1f).setDuration(140).start();
        }
    }

    // -------------------------------------------------------------- appearance

    private String theme() {
        return prefs.getString("theme", "dark");
    }

    private int background() {
        String t = theme();
        return t.equals("sepia") ? 0xFFF4ECD8 : t.equals("light") ? Color.WHITE : 0xFF111114;
    }

    private String css() {
        String t = theme();
        String bg, fg, link;
        if (t.equals("sepia")) {
            bg = "#F4ECD8"; fg = "#4A3B2A"; link = "#8A5A1E";
        } else if (t.equals("light")) {
            bg = "#FFFFFF"; fg = "#1B1B1B"; link = "#8A5A1E";
        } else {
            bg = "#111114"; fg = "#D9D5CC"; link = "#D4AF6A";
        }
        return "html,body{background:" + bg + " !important;color:" + fg + " !important;}"
                + "body{margin:0 !important;padding:22px 22px 56px !important;line-height:1.7 !important;"
                + "overflow-wrap:break-word;}"
                + "body *{color:inherit !important;background-color:transparent !important;max-width:100% !important;}"
                + "a,a *{color:" + link + " !important;}"
                + "img,svg,video{max-width:100% !important;height:auto !important;}"
                + "#__shelfNext{margin:40px 0 8px !important;padding:15px !important;text-align:center !important;"
                + "border:1px solid " + link + " !important;border-radius:12px !important;color:" + link
                + " !important;font:600 15px sans-serif !important;}";
    }

    /** Applies the theme, wires scroll/tap reporting and restores the reading position. */
    private void inject(float offset) {
        if (content == null || web == null) return;
        boolean hasNext = chapter + 1 < content.chapterCount();
        String js = "(function(){try{var d=document,r=d.documentElement;"
                + "var s=d.getElementById('__shelfCss');"
                + "if(!s){s=d.createElement('style');s.id='__shelfCss';(d.head||r).appendChild(s);}"
                + "s.textContent=" + JSONObject.quote(css()) + ";"
                + "var H=function(){var b=d.body;return Math.max(r.scrollHeight,b?b.scrollHeight:0)-window.innerHeight;};"
                + "var rep=function(){var h=H();Shelf.onScroll(h>4?Math.min(1,window.pageYOffset/h):1);};"
                + "if(!window.__shelfInit){window.__shelfInit=1;var t=0;"
                + "window.addEventListener('scroll',function(){clearTimeout(t);t=setTimeout(rep,150);},{passive:true});"
                + "d.addEventListener('click',function(e){var n=e.target;while(n&&n!==d){"
                + "var nm=(n.nodeName||'').toLowerCase();if(nm==='a'||n.id==='__shelfNext')return;n=n.parentNode;}"
                + "Shelf.tap();},false);"
                + (hasNext
                ? "var x=d.createElement('div');x.id='__shelfNext';x.textContent='Next section  ›';"
                + "x.addEventListener('click',function(){Shelf.next();},false);(d.body||r).appendChild(x);"
                : "")
                + "}"
                + "var f=" + (double) offset + ";if(f>0){window.scrollTo(0,Math.round(f*H()));}"
                + "setTimeout(rep,80);"
                + "}catch(e){}})();";
        web.evaluateJavascript(js, null);
    }

    private void applyTheme() {
        root.setBackgroundColor(background());
        web.setBackgroundColor(background());
        inject(-1f);
    }

    private void showTextSettings() {
        if (content == null) return;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(this, 20), Ui.dp(this, 14), Ui.dp(this, 20), Ui.dp(this, 6));

        LinearLayout themes = new LinearLayout(this);
        final ArrayList<TextView> chips = new ArrayList<>();
        final String[] names = {"Dark", "Sepia", "Light"};
        for (int i = 0; i < THEMES.length; i++) {
            final String key = THEMES[i];
            final TextView chip = chip(names[i]);
            chip.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    prefs.edit().putString("theme", key).apply();
                    applyTheme();
                    for (int k = 0; k < chips.size(); k++) mark(chips.get(k), THEMES[k].equals(key));
                }
            });
            mark(chip, key.equals(theme()));
            chips.add(chip);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(Ui.dp(this, 4), 0, Ui.dp(this, 4), 0);
            themes.addView(chip, lp);
        }
        box.addView(themes);

        LinearLayout sizes = new LinearLayout(this);
        sizes.setGravity(Gravity.CENTER_VERTICAL);
        final TextView value = new TextView(this);
        value.setTextColor(Ui.INK);
        value.setTextSize(14);
        value.setGravity(Gravity.CENTER);
        value.setText("Text size " + prefs.getInt("textZoom", 110) + "%");
        View.OnClickListener change = new View.OnClickListener() {
            @Override public void onClick(View v) {
                int step = "A+".contentEquals(((TextView) v).getText()) ? 10 : -10;
                int z = Math.max(70, Math.min(260, prefs.getInt("textZoom", 110) + step));
                prefs.edit().putInt("textZoom", z).apply();
                web.getSettings().setTextZoom(z);
                value.setText("Text size " + z + "%");
            }
        };
        TextView minus = chip("A−");
        TextView plus = chip("A+");
        minus.setOnClickListener(change);
        plus.setOnClickListener(change);
        mark(minus, false);
        mark(plus, false);
        LinearLayout.LayoutParams side = new LinearLayout.LayoutParams(Ui.dp(this, 64), ViewGroup.LayoutParams.WRAP_CONTENT);
        side.setMargins(Ui.dp(this, 4), Ui.dp(this, 16), Ui.dp(this, 4), 0);
        sizes.addView(minus, side);
        LinearLayout.LayoutParams mid = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        mid.topMargin = Ui.dp(this, 16);
        sizes.addView(value, mid);
        LinearLayout.LayoutParams side2 = new LinearLayout.LayoutParams(Ui.dp(this, 64), ViewGroup.LayoutParams.WRAP_CONTENT);
        side2.setMargins(Ui.dp(this, 4), Ui.dp(this, 16), Ui.dp(this, 4), 0);
        sizes.addView(plus, side2);
        box.addView(sizes);

        new AlertDialog.Builder(this).setTitle("Reading").setView(box).setPositiveButton("Done", null).show();
    }

    private TextView chip(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(14);
        t.setGravity(Gravity.CENTER);
        t.setPadding(Ui.dp(this, 8), Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 10));
        return t;
    }

    private void mark(TextView chip, boolean selected) {
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(Ui.dp(this, 10));
        bg.setColor(selected ? BookView.GOLD : 0x00000000);
        bg.setStroke(Ui.dp(this, 1), selected ? BookView.GOLD : 0x66D4AF6A);
        chip.setBackground(bg);
        chip.setTextColor(selected ? 0xFF17130B : Ui.INK);
    }

    private void showContents() {
        if (content == null) return;
        int n = content.chapterCount();
        int titled = 0;
        for (int i = 0; i < n; i++) if (content.chapterTitle(i) != null) titled++;
        final ArrayList<Integer> targets = new ArrayList<>();
        ArrayList<String> names = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            String t = content.chapterTitle(i);
            if (titled >= 2 && t == null) continue;
            targets.add(i);
            String name = t != null ? t : "Section " + (i + 1);
            names.add(i == chapter ? "▸ " + name : name);
        }
        new AlertDialog.Builder(this)
                .setTitle("Contents")
                .setItems(names.toArray(new String[0]), new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        go(targets.get(which), 0f);
                    }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    // ---------------------------------------------------------------- lifecycle

    @Override protected void onPause() {
        super.onPause();
        if (book != null && content != null) {
            book.chapter = chapter;
            book.offset = fraction;
            book.progress = progress();
            lib.save();
        }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        destroyed = true;
        if (web != null) {
            if (root != null) root.removeView(web);
            web.destroy();
        }
        final BookContent c = content;
        content = null;
        closeQuietly(c);
    }
}

package com.shelf.reader;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** The shelves: "Currently reading" on top, the rest of the library underneath. */
public class MainActivity extends Activity {
    private static final int PICK = 41;

    private static final class Row {
        String header;
        Book[] books;
        String hint;
    }

    private Library lib;
    private final ArrayList<Row> rows = new ArrayList<>();
    private RowAdapter adapter;
    private TextView subtitle;
    private int cols;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        lib = Library.get(this);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        cols = Math.max(3, Math.min(8, (int) (dm.widthPixels / dm.density / 118f)));

        FrameLayout root = new FrameLayout(this);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF15151C, 0xFF09090C}));

        ListView list = new ListView(this);
        list.setDivider(null);
        list.setDividerHeight(0);
        list.setSelector(new ColorDrawable(0));
        list.setCacheColorHint(0);
        list.setVerticalScrollBarEnabled(false);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(Ui.dp(this, 22), Ui.dp(this, 30), Ui.dp(this, 18), Ui.dp(this, 6));
        LinearLayout names = new LinearLayout(this);
        names.setOrientation(LinearLayout.VERTICAL);
        TextView title = new TextView(this);
        title.setText("Shelf");
        title.setTextSize(36);
        title.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
        title.setTextColor(0xFFF2ECDD);
        names.addView(title);
        subtitle = new TextView(this);
        subtitle.setTextSize(13);
        subtitle.setTextColor(0x99B8B2A6);
        names.addView(subtitle);
        header.addView(names, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView quotes = Ui.pill(this, "\u201C  Quotes", false);
        quotes.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, QuotesActivity.class));
            }
        });
        header.addView(quotes);
        TextView words = Ui.pill(this, "\u0639  Words", false);
        words.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, WordsActivity.class));
            }
        });
        LinearLayout.LayoutParams wlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT);
        wlp.leftMargin = Ui.dp(this, 8);
        header.addView(words, wlp);
        list.addHeaderView(header, null, false);

        View space = new View(this);
        space.setLayoutParams(new AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 100)));
        list.addFooterView(space, null, false);

        adapter = new RowAdapter();
        list.setAdapter(adapter);
        root.addView(list, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        TextView add = new TextView(this);
        add.setText("+");
        add.setTextSize(30);
        add.setIncludeFontPadding(false);
        add.setGravity(Gravity.CENTER);
        add.setTextColor(0xFF17130B);
        GradientDrawable circle = new GradientDrawable();
        circle.setShape(GradientDrawable.OVAL);
        circle.setColor(BookView.GOLD);
        add.setBackground(circle);
        add.setElevation(Ui.dp(this, 10));
        add.setContentDescription("Add books");
        add.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                pick();
            }
        });
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Ui.dp(this, 60), Ui.dp(this, 60),
                Gravity.BOTTOM | Gravity.END);
        lp.setMargins(0, 0, Ui.dp(this, 22), Ui.dp(this, 26));
        root.addView(add, lp);

        setContentView(root);
        if (state == null) handleIntent(getIntent());
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        handleIntent(intent);
    }

    @Override protected void onResume() {
        super.onResume();
        rebuild();
    }

    private void handleIntent(Intent intent) {
        if (intent != null && Intent.ACTION_VIEW.equals(intent.getAction()) && intent.getData() != null) {
            ArrayList<Uri> uris = new ArrayList<>();
            uris.add(intent.getData());
            importAll(uris, true);
        }
    }

    // ------------------------------------------------------------------ shelves

    private void rebuild() {
        List<Book> reading = new ArrayList<>();
        List<Book> library = new ArrayList<>();
        for (Book b : lib.all()) (b.reading ? reading : library).add(b);
        Collections.sort(reading, new Comparator<Book>() {
            @Override public int compare(Book a, Book b) {
                return Long.compare(b.opened, a.opened);
            }
        });
        Collections.sort(library, new Comparator<Book>() {
            @Override public int compare(Book a, Book b) {
                return Long.compare(b.added, a.added);
            }
        });

        rows.clear();
        addShelf("Currently reading", reading, "Books you open will wait for you here");
        addShelf("Library", library, reading.isEmpty()
                ? "Tap + to add PDF, EPUB or Kindle books"
                : "Every book is on your reading shelf");
        int total = reading.size() + library.size();
        subtitle.setText(total == 0 ? "Your shelves are empty" : total == 1 ? "1 book" : total + " books");
        adapter.notifyDataSetChanged();
    }

    private void addShelf(String name, List<Book> books, String emptyHint) {
        Row head = new Row();
        head.header = name.toUpperCase() + (books.isEmpty() ? "" : "   ·   " + books.size());
        rows.add(head);
        if (books.isEmpty()) {
            Row r = new Row();
            r.books = new Book[0];
            r.hint = emptyHint;
            rows.add(r);
            return;
        }
        for (int i = 0; i < books.size(); i += cols) {
            Row r = new Row();
            List<Book> part = books.subList(i, Math.min(books.size(), i + cols));
            r.books = part.toArray(new Book[0]);
            rows.add(r);
        }
    }

    private final class RowAdapter extends BaseAdapter {
        @Override public int getCount() { return rows.size(); }
        @Override public Object getItem(int position) { return rows.get(position); }
        @Override public long getItemId(int position) { return position; }
        @Override public int getViewTypeCount() { return 2; }
        @Override public int getItemViewType(int position) { return rows.get(position).header != null ? 0 : 1; }
        @Override public boolean areAllItemsEnabled() { return false; }
        @Override public boolean isEnabled(int position) { return false; }

        @Override public View getView(int position, View convertView, ViewGroup parent) {
            Row row = rows.get(position);
            if (row.header != null) {
                TextView t = convertView instanceof TextView ? (TextView) convertView : new TextView(MainActivity.this);
                t.setText(row.header);
                t.setTextSize(11.5f);
                t.setLetterSpacing(0.16f);
                t.setTypeface(Typeface.DEFAULT_BOLD);
                t.setTextColor(0xCCD4AF6A);
                t.setPadding(Ui.dp(MainActivity.this, 22), Ui.dp(MainActivity.this, 22),
                        Ui.dp(MainActivity.this, 22), Ui.dp(MainActivity.this, 2));
                return t;
            }
            ShelfRow shelf = convertView instanceof ShelfRow ? (ShelfRow) convertView
                    : new ShelfRow(MainActivity.this, cols);
            shelf.setHint(row.hint);
            for (int i = 0; i < shelf.slots.length; i++) {
                final Book b = i < row.books.length ? row.books[i] : null;
                BookView v = shelf.slots[i];
                v.setBook(b);
                if (b == null) {
                    v.setOnClickListener(null);
                    v.setOnLongClickListener(null);
                    v.setClickable(false);
                    v.setLongClickable(false);
                } else {
                    v.setContentDescription(b.title);
                    v.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View view) {
                            open(b);
                        }
                    });
                    v.setOnLongClickListener(new View.OnLongClickListener() {
                        @Override public boolean onLongClick(View view) {
                            menu(b);
                            return true;
                        }
                    });
                }
            }
            return shelf;
        }
    }

    // ------------------------------------------------------------------ actions

    private void open(Book b) {
        if (!new File(b.file).exists()) {
            Ui.toast(this, "This book's file is missing");
            return;
        }
        b.reading = true;
        b.opened = System.currentTimeMillis();
        lib.save();
        Intent i = new Intent(this, b.format.equals("pdf") ? PdfActivity.class : ReaderActivity.class);
        i.putExtra("id", b.id);
        startActivity(i);
    }

    private void menu(final Book b) {
        final String move = b.reading ? "Move back to Library" : "Move to Currently reading";
        String[] items = {"Open", "Rename", move, "Delete"};
        new AlertDialog.Builder(this)
                .setTitle(b.title)
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        if (which == 0) {
                            open(b);
                        } else if (which == 1) {
                            rename(b);
                        } else if (which == 2) {
                            b.reading = !b.reading;
                            if (b.reading) b.opened = System.currentTimeMillis();
                            lib.save();
                            rebuild();
                        } else {
                            confirmDelete(b);
                        }
                    }
                })
                .show();
    }

    private EditText field(LinearLayout box, String caption, String value) {
        TextView label = new TextView(this);
        label.setText(caption);
        label.setTextSize(12);
        label.setTextColor(0xCCD4AF6A);
        label.setPadding(Ui.dp(this, 4), Ui.dp(this, 10), 0, 0);
        box.addView(label);
        EditText edit = new EditText(this);
        edit.setSingleLine(true);
        edit.setText(value);
        box.addView(edit);
        return edit;
    }

    private void rename(final Book b) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(this, 20), Ui.dp(this, 4), Ui.dp(this, 20), 0);
        final EditText name = field(box, "Book name", b.title);
        final EditText author = field(box, "Author", b.author);
        new AlertDialog.Builder(this)
                .setTitle("Rename")
                .setView(box)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        String title = name.getText().toString().replaceAll("\\s+", " ").trim();
                        if (title.isEmpty()) {
                            Ui.toast(MainActivity.this, "The book name can't be empty");
                            return;
                        }
                        b.title = title;
                        b.author = author.getText().toString().replaceAll("\\s+", " ").trim();
                        lib.save();
                        Quotes.renamed(MainActivity.this, b);
                        rebuild();
                    }
                })
                .show();
    }

    private void confirmDelete(final Book b) {
        new AlertDialog.Builder(this)
                .setTitle("Delete this book?")
                .setMessage("“" + b.title + "” will be removed from your shelves. "
                        + "Your original file on the phone is not touched, and quotes you saved from it are kept. "
                        + "Drawings and highlights in it are deleted.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface dialog, int which) {
                        lib.remove(b);
                        Ink.delete(MainActivity.this, b.id);
                        rebuild();
                    }
                })
                .show();
    }

    private void pick() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        try {
            startActivityForResult(i, PICK);
        } catch (ActivityNotFoundException e) {
            Ui.toast(this, "No file picker is available on this device");
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK || resultCode != RESULT_OK || data == null) return;
        ArrayList<Uri> uris = new ArrayList<>();
        ClipData clip = data.getClipData();
        if (clip != null) {
            for (int i = 0; i < clip.getItemCount(); i++) {
                Uri u = clip.getItemAt(i).getUri();
                if (u != null) uris.add(u);
            }
        } else if (data.getData() != null) {
            uris.add(data.getData());
        }
        if (!uris.isEmpty()) importAll(uris, false);
    }

    private void importAll(final List<Uri> uris, final boolean openAfter) {
        final AlertDialog progress = new AlertDialog.Builder(this)
                .setMessage(uris.size() == 1 ? "Adding to your shelves…" : "Adding " + uris.size() + " books…")
                .setCancelable(false)
                .show();
        new Thread(new Runnable() {
            @Override public void run() {
                int ok = 0;
                Book last = null;
                final StringBuilder errors = new StringBuilder();
                for (Uri u : uris) {
                    try {
                        last = lib.importUri(getApplicationContext(), u);
                        ok++;
                    } catch (Exception | OutOfMemoryError e) {
                        if (errors.length() > 0) errors.append("\n\n");
                        errors.append(e.getMessage() == null ? "A file could not be added" : e.getMessage());
                    }
                }
                final int added = ok;
                final Book book = last;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (isDestroyed()) return;
                        progress.dismiss();
                        rebuild();
                        if (errors.length() > 0) {
                            new AlertDialog.Builder(MainActivity.this)
                                    .setTitle(added == 0 ? "Couldn't add" : "Some files were skipped")
                                    .setMessage(errors.toString())
                                    .setPositiveButton("OK", null)
                                    .show();
                        } else if (openAfter && book != null) {
                            open(book);
                        } else if (added == 1 && book != null) {
                            Ui.toast(MainActivity.this, "Added “" + book.title + "”");
                        } else {
                            Ui.toast(MainActivity.this, added + " books added");
                        }
                    }
                });
            }
        }).start();
    }
}

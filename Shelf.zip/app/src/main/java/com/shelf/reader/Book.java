package com.shelf.reader;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/** One book on the shelves. */
final class Book {
    String id = "";
    String title = "";
    String author = "";
    /** "pdf", "epub" or "mobi". */
    String format = "";
    /** Absolute path of the app's private copy of the file. */
    String file = "";
    /** Absolute path of the cover image, or empty. */
    String cover = "";
    String source = "";
    long size;
    boolean reading;
    float progress;
    /** Page (PDF) or chapter (EPUB/MOBI) the reader stopped at. */
    int chapter;
    /** Position inside the chapter, 0..1. */
    float offset;
    long added;
    long opened;
    final ArrayList<Mark> marks = new ArrayList<>();

    /** A bookmark: a page (PDF) or a place inside a section (EPUB/Kindle). */
    static final class Mark {
        int chapter;
        float offset;
        String label = "";
        long time;
    }

    void sortMarks() {
        Collections.sort(marks, new Comparator<Mark>() {
            @Override public int compare(Mark a, Mark b) {
                return a.chapter != b.chapter ? Integer.compare(a.chapter, b.chapter) : Float.compare(a.offset, b.offset);
            }
        });
    }

    JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("title", title);
        o.put("author", author);
        o.put("format", format);
        o.put("file", file);
        o.put("cover", cover);
        o.put("source", source);
        o.put("size", size);
        o.put("reading", reading);
        o.put("progress", (double) progress);
        o.put("chapter", chapter);
        o.put("offset", (double) offset);
        o.put("added", added);
        o.put("opened", opened);
        JSONArray arr = new JSONArray();
        for (Mark m : marks) {
            JSONObject j = new JSONObject();
            j.put("chapter", m.chapter);
            j.put("offset", (double) m.offset);
            j.put("label", m.label);
            j.put("time", m.time);
            arr.put(j);
        }
        o.put("marks", arr);
        return o;
    }

    static Book fromJson(JSONObject o) {
        Book b = new Book();
        b.id = o.optString("id", "");
        b.title = o.optString("title", "");
        b.author = o.optString("author", "");
        b.format = o.optString("format", "");
        b.file = o.optString("file", "");
        b.cover = o.optString("cover", "");
        b.source = o.optString("source", "");
        b.size = o.optLong("size", 0);
        b.reading = o.optBoolean("reading", false);
        b.progress = (float) o.optDouble("progress", 0);
        b.chapter = o.optInt("chapter", 0);
        b.offset = (float) o.optDouble("offset", 0);
        b.added = o.optLong("added", 0);
        b.opened = o.optLong("opened", 0);
        JSONArray arr = o.optJSONArray("marks");
        for (int i = 0; arr != null && i < arr.length(); i++) {
            JSONObject j = arr.optJSONObject(i);
            if (j == null) continue;
            Mark m = new Mark();
            m.chapter = j.optInt("chapter", 0);
            m.offset = (float) j.optDouble("offset", 0);
            m.label = j.optString("label", "");
            m.time = j.optLong("time", 0);
            b.marks.add(m);
        }
        return b;
    }
}

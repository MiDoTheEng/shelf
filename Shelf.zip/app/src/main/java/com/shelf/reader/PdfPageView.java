package com.shelf.reader;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

/** Shows one PDF page at a time: swipe to turn, pinch or double-tap to zoom, drag to move. */
final class PdfPageView extends View {
    interface Listener {
        void onTurn(int delta);
        void onTap();
        void onZoomSettled(float zoom);
    }

    Listener listener;
    /** The swipe that goes to the next page: "left", "right" or "up". */
    String mode = "left";

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final RectF dst = new RectF();
    private final ScaleGestureDetector scaler;
    private final GestureDetector gestures;
    private final float minSwipe;
    private Bitmap bitmap;
    private boolean night;
    private float zoom = 1f, panX, panY;
    private float downX, downY;
    private boolean multi, zoomChanged;

    PdfPageView(Context c) {
        super(c);
        minSwipe = 52 * c.getResources().getDisplayMetrics().density;
        scaler = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) {
                zoomTo(zoom * d.getScaleFactor(), d.getFocusX(), d.getFocusY());
                return true;
            }
        });
        gestures = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) {
                return true;
            }

            @Override public boolean onScroll(MotionEvent e1, MotionEvent e2, float dx, float dy) {
                if (zoom > 1.02f) {
                    panX -= dx;
                    panY -= dy;
                    invalidate();
                }
                return true;
            }

            @Override public boolean onSingleTapConfirmed(MotionEvent e) {
                if (listener != null) listener.onTap();
                return true;
            }

            @Override public boolean onDoubleTap(MotionEvent e) {
                zoomTo(zoom > 1.02f ? 1f : 2.2f, e.getX(), e.getY());
                zoomChanged = false;
                if (listener != null) listener.onZoomSettled(zoom);
                return true;
            }
        });
    }

    float zoom() {
        return zoom;
    }

    void setBitmap(Bitmap b, boolean resetView) {
        bitmap = b;
        if (resetView) {
            zoom = 1f;
            panX = 0;
            panY = 0;
        }
        invalidate();
    }

    void setNight(boolean on) {
        night = on;
        paint.setColorFilter(on ? PdfActivity.INVERT : null);
        invalidate();
    }

    private void zoomTo(float target, float fx, float fy) {
        float old = zoom;
        zoom = Math.max(1f, Math.min(4f, target));
        float cx = fx - getWidth() / 2f, cy = fy - getHeight() / 2f;
        panX = (panX - cx) * (zoom / old) + cx;
        panY = (panY - cy) * (zoom / old) + cy;
        zoomChanged = true;
        invalidate();
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        scaler.onTouchEvent(e);
        if (!scaler.isInProgress()) gestures.onTouchEvent(e);
        int action = e.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN) {
            downX = e.getX();
            downY = e.getY();
            multi = false;
        } else if (action == MotionEvent.ACTION_POINTER_DOWN) {
            multi = true;
        } else if (action == MotionEvent.ACTION_UP) {
            if (zoomChanged) {
                zoomChanged = false;
                if (listener != null) listener.onZoomSettled(zoom);
            } else if (!multi && zoom <= 1.02f && listener != null) {
                float dx = e.getX() - downX, dy = e.getY() - downY;
                int delta = 0;
                if (mode.equals("up")) {
                    if (Math.abs(dy) > minSwipe && Math.abs(dy) > 1.5f * Math.abs(dx)) delta = dy < 0 ? 1 : -1;
                } else if (Math.abs(dx) > minSwipe && Math.abs(dx) > 1.5f * Math.abs(dy)) {
                    delta = (dx < 0) == mode.equals("left") ? 1 : -1;
                }
                if (delta != 0) listener.onTurn(delta);
            }
        } else if (action == MotionEvent.ACTION_CANCEL) {
            zoomChanged = false;
        }
        return true;
    }

    @Override protected void onDraw(Canvas canvas) {
        float w = getWidth(), h = getHeight();
        if (bitmap == null || w == 0 || h == 0) return;
        float bw = bitmap.getWidth(), bh = bitmap.getHeight();
        float fit = Math.min(w / bw, h / bh);
        float dw = bw * fit * zoom, dh = bh * fit * zoom;
        float maxX = Math.max(0, (dw - w) / 2f), maxY = Math.max(0, (dh - h) / 2f);
        panX = Math.max(-maxX, Math.min(maxX, panX));
        panY = Math.max(-maxY, Math.min(maxY, panY));
        float left = (w - dw) / 2f + panX, top = (h - dh) / 2f + panY;
        dst.set(left, top, left + dw, top + dh);
        canvas.drawBitmap(bitmap, null, dst, paint);
    }
}

package com.shelf.reader;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.GestureDetector;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

/**
 * Shows one PDF page at a time: swipe to turn, pinch or double-tap to zoom, drag to move,
 * hold on a word to select text and drag (or pull the two handles) to extend it.
 */
final class PdfPageView extends View {
    interface Listener {
        void onTurn(int delta);
        void onTap();
        void onZoomSettled(float zoom);
        /** Asks for the text between a and b; word is true when a single word was held. */
        void onSelect(PdfSelect.Bound a, PdfSelect.Bound b, boolean word);
        void onSelectClear();
    }

    private static final int NONE = 0, MOVE_STOP = 1, MOVE_START = 2;

    Listener listener;
    /** The swipe that goes to the next page: "left", "right" or "up". */
    String mode = "left";

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint selPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint handlePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF dst = new RectF();
    private final float[] handles = new float[4];
    private final ScaleGestureDetector scaler;
    private final GestureDetector gestures;
    private final float d;
    private Bitmap bitmap;
    private float zoom = 1f, panX, panY;
    private float downX, downY;
    private boolean multi, zoomChanged;

    private PdfSelect.Result sel;
    private int drag = NONE;
    private boolean handleGesture, selectGesture;
    /** The end that stays put while a handle is pulled. */
    private PdfSelect.Bound fixed;
    /** The word first picked by holding; dragging on extends from it. */
    private PdfSelect.Result word;
    private PdfSelect.Bound anchor;
    private float holdX, holdY;

    PdfPageView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        selPaint.setColor(0x66D4AF6A);
        handlePaint.setColor(BookView.GOLD);
        scaler = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector det) {
                zoomTo(zoom * det.getScaleFactor(), det.getFocusX(), det.getFocusY());
                return true;
            }
        });
        gestures = new GestureDetector(c, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) {
                return true;
            }

            @Override public boolean onScroll(MotionEvent e1, MotionEvent e2, float dx, float dy) {
                if (zoom > 1.02f) {
                    panX -= dx;
                    panY -= dy;
                    invalidate();
                }
                return true;
            }

            @Override public boolean onSingleTapConfirmed(MotionEvent e) {
                if (listener == null) return true;
                if (sel != null) listener.onSelectClear();
                else listener.onTap();
                return true;
            }

            @Override public boolean onDoubleTap(MotionEvent e) {
                zoomTo(zoom > 1.02f ? 1f : 2.2f, e.getX(), e.getY());
                zoomChanged = false;
                if (listener != null) listener.onZoomSettled(zoom);
                return true;
            }

            @Override public void onLongPress(MotionEvent e) {
                if (listener == null || bitmap == null || multi) return;
                place();
                holdX = e.getX();
                holdY = e.getY();
                anchor = spot(holdX, holdY);
                drag = MOVE_STOP;
                word = null;
                selectGesture = true;
                performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
                listener.onSelect(anchor, anchor, true);
            }
        });
    }

    float zoom() {
        return zoom;
    }

    void setBitmap(Bitmap b, boolean resetView) {
        bitmap = b;
        if (resetView) {
            zoom = 1f;
            panX = 0;
            panY = 0;
        }
        invalidate();
    }

    void setNight(boolean on) {
        paint.setColorFilter(on ? PdfActivity.INVERT : null);
        invalidate();
    }

    /** Shows (or with null, removes) the highlighted selection. */
    void setSelection(PdfSelect.Result r, boolean wordResult) {
        sel = r;
        // The first answer to a hold is the word under the finger; dragging on extends from it.
        if (r != null && wordResult && drag == MOVE_STOP && !handleGesture) word = r;
        invalidate();
    }

    private void zoomTo(float target, float fx, float fy) {
        float old = zoom;
        zoom = Math.max(1f, Math.min(4f, target));
        float cx = fx - getWidth() / 2f, cy = fy - getHeight() / 2f;
        panX = (panX - cx) * (zoom / old) + cx;
        panY = (panY - cy) * (zoom / old) + cy;
        zoomChanged = true;
        invalidate();
    }

    /** Works out where the page sits on screen for the current zoom and position. */
    private boolean place() {
        float w = getWidth(), h = getHeight();
        if (bitmap == null || w == 0 || h == 0) return false;
        float bw = bitmap.getWidth(), bh = bitmap.getHeight();
        float fit = Math.min(w / bw, h / bh);
        float dw = bw * fit * zoom, dh = bh * fit * zoom;
        float maxX = Math.max(0, (dw - w) / 2f), maxY = Math.max(0, (dh - h) / 2f);
        panX = Math.max(-maxX, Math.min(maxX, panX));
        panY = Math.max(-maxY, Math.min(maxY, panY));
        float left = (w - dw) / 2f + panX, top = (h - dh) / 2f + panY;
        dst.set(left, top, left + dw, top + dh);
        return true;
    }

    private PdfSelect.Bound spot(float x, float y) {
        float u = (x - dst.left) / Math.max(1f, dst.width()), v = (y - dst.top) / Math.max(1f, dst.height());
        return PdfSelect.Bound.at(Math.max(0f, Math.min(1f, u)), Math.max(0f, Math.min(1f, v)));
    }

    /** Screen positions of the start handle (0,1) and the stop handle (2,3); false when nothing is selected. */
    private boolean handlePositions() {
        if (sel == null || sel.rects.isEmpty() || !place()) return false;
        RectF first = sel.rects.get(0), last = sel.rects.get(sel.rects.size() - 1);
        handles[0] = dst.left + (sel.rtl ? first.right : first.left) * dst.width();
        handles[1] = dst.top + first.bottom * dst.height() + 10 * d;
        handles[2] = dst.left + (sel.rtl ? last.left : last.right) * dst.width();
        handles[3] = dst.top + last.bottom * dst.height() + 10 * d;
        return true;
    }

    private void extendTo(float x, float y) {
        if (listener == null || !place()) return;
        PdfSelect.Bound p = spot(x, y);
        if (handleGesture) {
            if (fixed == null) return;
            if (drag == MOVE_STOP) listener.onSelect(fixed, p, false);
            else listener.onSelect(p, fixed, false);
            return;
        }
        if (word == null || word.rects.isEmpty()) return;
        // Dragging on from a held word: forwards keeps the word's start, backwards keeps its end.
        RectF first = word.rects.get(0);
        boolean before = p.v < first.top
                || (p.v <= first.bottom && (word.rtl ? p.u > first.right : p.u < first.left));
        if (before) listener.onSelect(p, PdfSelect.Bound.at(word.eu, word.ev), false);
        else listener.onSelect(PdfSelect.Bound.at(word.su, word.sv), p, false);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        int action = e.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN) {
            downX = e.getX();
            downY = e.getY();
            multi = false;
            drag = NONE;
            handleGesture = false;
            selectGesture = false;
            if (handlePositions()) {
                float reach = 36 * d;
                float toStop = (float) Math.hypot(downX - handles[2], downY - handles[3]);
                float toStart = (float) Math.hypot(downX - handles[0], downY - handles[1]);
                if (Math.min(toStop, toStart) < reach) {
                    boolean stop = toStop <= toStart;
                    drag = stop ? MOVE_STOP : MOVE_START;
                    fixed = stop ? PdfSelect.Bound.at(sel.su, sel.sv) : PdfSelect.Bound.at(sel.eu, sel.ev);
                    handleGesture = true;
                    return true;
                }
            }
        }
        if (handleGesture) {
            // Aim a little above the finger, at the line the handle hangs from.
            if (action == MotionEvent.ACTION_MOVE) {
                extendTo(e.getX(), e.getY() - 20 * d);
            } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                drag = NONE;
                handleGesture = false;
            }
            return true;
        }

        scaler.onTouchEvent(e);
        if (!scaler.isInProgress()) gestures.onTouchEvent(e);
        if (action == MotionEvent.ACTION_POINTER_DOWN) {
            multi = true;
        } else if (action == MotionEvent.ACTION_MOVE) {
            if (drag == MOVE_STOP && Math.hypot(e.getX() - holdX, e.getY() - holdY) > 10 * d) {
                extendTo(e.getX(), e.getY());
            }
        } else if (action == MotionEvent.ACTION_UP) {
            if (selectGesture) {
                drag = NONE;
            } else if (zoomChanged) {
                zoomChanged = false;
                if (listener != null) listener.onZoomSettled(zoom);
            } else if (!multi && zoom <= 1.02f && listener != null) {
                float dx = e.getX() - downX, dy = e.getY() - downY;
                float min = 52 * d;
                int delta = 0;
                if (mode.equals("up")) {
                    if (Math.abs(dy) > min && Math.abs(dy) > 1.5f * Math.abs(dx)) delta = dy < 0 ? 1 : -1;
                } else if (Math.abs(dx) > min && Math.abs(dx) > 1.5f * Math.abs(dy)) {
                    delta = (dx < 0) == mode.equals("left") ? 1 : -1;
                }
                if (delta != 0) listener.onTurn(delta);
            }
        } else if (action == MotionEvent.ACTION_CANCEL) {
            zoomChanged = false;
            drag = NONE;
        }
        return true;
    }

    @Override protected void onDraw(Canvas canvas) {
        if (!place()) return;
        canvas.drawBitmap(bitmap, null, dst, paint);
        if (sel == null) return;
        for (RectF r : sel.rects) {
            canvas.drawRect(dst.left + r.left * dst.width(), dst.top + r.top * dst.height(),
                    dst.left + r.right * dst.width(), dst.top + r.bottom * dst.height(), selPaint);
        }
        if (handlePositions()) {
            canvas.drawCircle(handles[0], handles[1], 10 * d, handlePaint);
            canvas.drawCircle(handles[2], handles[3], 10 * d, handlePaint);
        }
    }
}
